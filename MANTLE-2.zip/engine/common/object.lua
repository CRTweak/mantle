---@class Object : Class
---@field x      number The horizontal position of the object, relative to its parent.
---@field y      number The vertical position of the object, relative to its parent.
---@overload fun(x?:number, y?:number, width?:number, height?:number) : Object
local Object = Class()

function Object:init(x, y, width, height)
    self.x = x or 0
    self.y = y or 0
    self.width = width or 16
    self.height = height or 16
end

function Object:update()

end

return Object
