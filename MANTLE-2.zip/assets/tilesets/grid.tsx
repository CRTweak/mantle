<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.2" name="grid" tilewidth="32" tileheight="32" tilecount="1024" columns="32">
 <editorsettings>
  <export target="grid.lua" format="lua"/>
 </editorsettings>
 <image source="../sprites/tilesets/grid.png" width="1024" height="1024"/>
 <tile id="992">
  <animation>
   <frame tileid="992" duration="100"/>
   <frame tileid="993" duration="100"/>
   <frame tileid="994" duration="100"/>
   <frame tileid="929" duration="100"/>
   <frame tileid="930" duration="100"/>
   <frame tileid="865" duration="100"/>
  </animation>
 </tile>
</tileset>
