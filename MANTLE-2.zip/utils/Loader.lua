local Loader = {}

function Loader.loadFolder(path)
    local objects = {}

    for _, file in ipairs(love.filesystem.getDirectoryItems(path)) do
        if file:match("%.lus$") then
            local name = file:gsub("%.lua$", "")
            local mod = require(path:gsub("/", ".").."."..name)
            objects[name] = mod
        end
    end
    return objects
end

return Loader