function love.conf(t)
    t.window.title = "MANTLE v0.1"
    t.window.icon = "icon.png"
    t.window.width = 640
    t.window.height = 480
end